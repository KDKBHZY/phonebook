//
//  detailTableViewController.swift
//  communication
//
//  Created by ZY H on 2021/3/31.
//

import UIKit

class detailTableViewController: UITableViewController {

    var per:Person?
    var completion:(()->())?
    
    @IBOutlet weak var nametext: UITextField!
    
    @IBOutlet weak var phonetext: UITextField!
    
    @IBOutlet weak var elsetext: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//判断per是否优质
        if per != nil{
            nametext.text = per?.name
            phonetext.text = per?.phone
            elsetext.text = per?.title
        }
       
    }


    
    @IBAction func save(_ sender: Any) {
        if per == nil{
            print("p为空1")
            per = Person()
            
        }
//        更新内容
        per?.name = nametext.text
        per?.phone = phonetext.text
        per?.title = elsetext.text
        //闭包回调
        completion?()
        //返回
        navigationController?.popViewController(animated: true)
    }
    
}
