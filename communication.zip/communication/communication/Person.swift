//
//  Person.swift
//  communication
//
//  Created by ZY H on 2021/3/31.
//

import UIKit

class Person: NSObject {
    var name:String?
    var phone:String?
    var title:String?

}
