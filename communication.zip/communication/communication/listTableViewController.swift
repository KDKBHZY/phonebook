//
//  listTableViewController.swift
//  communication
//
//  Created by ZY H on 2021/3/31.
//

import UIKit

class listTableViewController: UITableViewController {
    var perlist = [Person]()

    override func viewDidLoad() {
        super.viewDidLoad()

        loaddata { (list:[Person]) in
            print(list)
            self.perlist += list
            //刷新表格
            self.tableView.reloadData()
        }
    }
//模拟异步，利用闭包回调
    func loaddata( completion:@escaping (_ list:[Person])->()) -> () {
        DispatchQueue.global().async {
            print("正在加载。。")
            Thread.sleep(forTimeInterval: 1)
            var arrm = [Person]()
            for i in 0..<5{
                let p = Person()
                p.name = "\(i)张三"
                p.phone = "1860" + String(format: "%06d", arc4random_uniform(10000))
                p.title  = "boss"
                arrm.append(p)
            }
            //主线程回调
            
            DispatchQueue.main.async(execute: {
                //回调，执行闭包
                completion(arrm)
            })
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return perlist.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath)
        cell.textLabel?.text = perlist[indexPath.row].name
        cell.detailTextLabel?.text = perlist[indexPath.row].phone
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        //执行segue
        performSegue(withIdentifier: "listtodetail", sender: indexPath)
    }
    //赋值
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! detailTableViewController
        //设置选中的person
        if let indexpath:IndexPath = sender as? IndexPath{
            vc.per = perlist[indexpath.row]
            //设置编辑完成的闭包
            vc.completion = {
                self.tableView.reloadRows(at: [indexpath], with: .automatic)
            }
        }
        //没有indexpath就是新建
        else{
            //设置新建的闭包
            vc.completion = {
                guard let p1 = vc.per else {
                    print("p为空")
                    return
                }
                
    //            插入数组
                self.perlist.append(p1)
    //            刷新表格
                self.tableView.reloadData()
                
            }
//            1.获取person
           
        }
    }
   
    @IBAction func add(_ sender: Any) {
        //执行跳转
        performSegue(withIdentifier: "listtodetail", sender: nil)
    }
    
}
